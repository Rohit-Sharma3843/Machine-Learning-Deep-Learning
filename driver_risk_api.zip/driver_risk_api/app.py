from flask import Flask, render_template, request
import numpy as np
import pickle
import os
from sklearn.preprocessing import MinMaxScaler

app = Flask(__name__)

MODEL_PATH = "models"
MODELS = {
    "Decision Tree": "DecisionTree.model",
    "Extra Trees": "ExtraTrees.model",
    "Gradient Boosting": "GradientBoosting.model",
    "KNN": "KNN.model",
    "Linear Regression": "LinearRegression.model",
    "MLP": "MLP.model",
    "Random Forest": "RandomForest.model",
    "SVR": "SVR.model"
}

# Encoding maps
gender_map = {"Female": 0, "Male": 1}
helmet_map = {"No": 0, "Not required": 1, "Yes": 2}
seatbelt_map = {"No": 0, "Not available": 1, "Yes": 2}
road_map = {"Dry": 0, "Gravel": 1, "Snow": 2, "Wet": 3}
weather_map = {"Clear": 0, "Cloudy": 1, "Dust Storm": 2, "Foggy": 3, "Rainy": 4}
breath_map = {"Negative": 0, "Not Available": 1, "Positive": 2}
vehicle_map = {"Auto": 0, "Bike": 1, "Bus": 2, "Car": 3, "Scooter": 4, "Truck": 5}

scaler = MinMaxScaler(feature_range=(0, 1))
scaler.fit([[18], [100]])  # Expected age range

def load_model(model_name):
    path = os.path.join(MODEL_PATH, MODELS[model_name])
    with open(path, "rb") as f:
        return pickle.load(f)

@app.route("/")
def home():
    return render_template("index.html", models=MODELS.keys())

@app.route("/predict", methods=["POST"])
def predict():
    try:
        model_name = request.form.get("model")
        model = load_model(model_name)

        # Categorical encodings
        f1 = gender_map[request.form["Driver_Gender"]]
        f2 = float(request.form["Driver_Age"])
        f2 = scaler.transform([[f2]])[0][0]  # scaled age
        f3 = helmet_map[request.form["Helmet_Worn"]]
        f4 = seatbelt_map[request.form["Seatbelt_Worn"]]
        f5 = road_map[request.form["Road_Condition"]]
        f6 = weather_map[request.form["Weather_Condition"]]
        f7 = breath_map[request.form["Breathalyzer_Result"]]
        f8 = vehicle_map[request.form["Vehicle_Type"]]

        # Additional numeric features
        f9 = float(request.form["f9"])
        f10 = float(request.form["f10"])
        f11 = float(request.form["f11"])
        f12 = float(request.form["f12"])
        f13 = float(request.form["f13"])
        f14 = float(request.form["f14"])
        f15 = float(request.form["f15"])

        features = [f1, f2, f3, f4, f5, f6, f7, f8,
                    f9, f10, f11, f12, f13, f14, f15]

        prediction = model.predict([features])
        score = round(float(prediction[0]), 2)

        return render_template("index.html",
                               prediction_text=f"{model_name} → Risk Score: {score}",
                               models=MODELS.keys())

    except Exception as e:
        return render_template("index.html",
                               prediction_text=f"Error: {str(e)}",
                               models=MODELS.keys())

if __name__ == "__main__":
    app.run(debug=True)
